package test;

import controls.IManager;
import controls.MySystemManager;

public class TestMySystem {

	public static void main(String[] args) {
		IManager instance = MySystemManager.getInstance();
		instance.run();
	}
}
