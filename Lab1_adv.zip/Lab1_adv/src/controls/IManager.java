package controls;

public interface IManager {

	void run();
}
