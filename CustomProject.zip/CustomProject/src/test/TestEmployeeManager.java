package test;

import controls.EmploeeManagement;

public class TestEmployeeManager {
	public static void main(String[] args) {
		new EmploeeManagement().run();
	}
}
