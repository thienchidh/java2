<b>Bài tập hướng đối tượng</b> 
   Bài tập cộng trừ nhân chia:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/blob/master/Tai/HelloJava/src/HelloJava.java"> link</a><br>
   Phuong trình bậc nhất:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/blob/master/Tai/HelloJava/src/ptbn.java"> link</a><br>
   Bảng cửu chương:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/blob/master/Tai/HelloJava/src/bangcuuchuong.java"> link</a><br>
   Tính tiền điện:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/blob/master/Tai/HelloJava/src/tinhtiendien.java"> link</a><br>
   Menu:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/blob/master/Tai/HelloJava/src/menu.java"> link</a><br>
   Bài tập về nhà:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/blob/master/Tai/HelloJava/src/mang.java"> link</a><br>
   Hướng đối tương p1:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/tree/master/Tai/QLSV/src"> link</a><br>
   Bài tập về nhà 2:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/tree/master/Tai/Lad03/src"> link</a><br>
   SETER,GETER:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/tree/master/Tai/QLSV1/src"> link</a><br>
   Bài tập về nhà 3:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/tree/master/Tai/QLSV1/src"> link</a><br>
  Assignment 7:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/tree/master/Tai/QLSV1/src"> link</a><br>
  Thi thử:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/tree/master/Tai/Shop"> link</a><br>
  Thi:
   <a href="https://github.com/FASTTRACKSE/FTJD1803/tree/master/Tai/Thi"> link</a><br>
   <hr>
   <b>Truy vấn My SQL</b> 
   Bài tập về nhà My SQL:
   <a href = "https://github.com/FASTTRACKSE/FTJD1803/tree/master/Tai/THPTHoaVang/src">link</a><br>
   <hr>
   <b>Java Swing</b><br> 
   Bài làm trên lớp:
   <a href = "https://github.com/FASTTRACKSE/FTJD1803/blob/master/Tai/GiaoDien/src/MyWindow.java">link</a><br>
   <hr>
   <b>New Java</b>
    ManagerStudent
  <a href="https://github.com/Taiphan123/Java/tree/master/nangcaob1/src/StudentManagement"> link </a><br>
  
