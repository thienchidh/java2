
public interface Bai2 {
	void doThang(int thang);
	void tocDo(int tocDo);
	void canNang(int kg);
}
