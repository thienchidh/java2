
public class staticDemo {
	public static void main(String[] args) {
		Student s1 = new Student ("b",1);
		Student s2 = new Student ("a",2);
		Student.setCollegeName("dai hoc kien truc");
		s2.getSutdentInfor();
		s1.getSutdentInfor();
	}
}
