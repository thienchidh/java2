package homework;

import java.util.ArrayList;

public class Exercise2 {

	public static void main(String[] args) {
		// khoi tao arraylist
		ArrayList<Integer> soNguyen = new ArrayList<Integer>();
		
		// vong lap nhap vao
		for (int i = 0; i < 10; i++) {
			soNguyen.add(i);
		}
			System.out.println(soNguyen);
	}
}
