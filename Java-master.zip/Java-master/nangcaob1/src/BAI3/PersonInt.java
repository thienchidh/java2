package BAI3;

public interface PersonInt {
	public void input();

	public void display();
}
