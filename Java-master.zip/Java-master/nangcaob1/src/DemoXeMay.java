
public class DemoXeMay {
	public static void main(String[] args) {
		XeMay xemay = new XeMay();
		xemay.kg=100;
		xemay.thang=10;
		xemay.tocDo=1000;
		xemay.print();
	}
}
