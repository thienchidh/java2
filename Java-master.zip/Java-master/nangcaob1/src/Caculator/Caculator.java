package Caculator;
public class Caculator {
	public int add(int a, int b) {
		return a+b;
	}
}
