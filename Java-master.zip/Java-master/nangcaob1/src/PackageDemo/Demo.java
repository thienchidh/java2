package PackageDemo;

import Caculator.Caculator;

public class Demo {
	public static void main(String[] args) {
		Caculator obj = new Caculator();
		System.out.println(obj.add(9, 10));
	}
}