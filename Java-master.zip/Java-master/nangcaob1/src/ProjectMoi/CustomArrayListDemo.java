package ProjectMoi;

public class CustomArrayListDemo {
	
	int n= 4;
	public void addValue(int roll[], String name[], int marks[], String phone[]) {
		
	}
}
