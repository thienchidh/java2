package ProjectMoi;

public class Customer {
	
	int roll;
	String name;
	int marks;
	long phone;
	public Customer(int roll, String name, int marks, long phone) {
		super();
		this.roll = roll;
		this.name = name;
		this.marks = marks;
		this.phone = phone;
	}
	
}