package Assignment6;

public class Assignmen6 {

	public static void main(String[] args) {
		menu.main();
	}

}
