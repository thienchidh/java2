package java2.lession;

public class Main {
	public static void main(String[] args) {
		//exception la loi chuong trinh
	}
}
