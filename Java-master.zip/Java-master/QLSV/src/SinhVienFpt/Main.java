package SinhVienFpt;

public class Main {
	public static void main(String[] args) {
		Menu n= new Menu();
		n.Menu();
	}

	
}
