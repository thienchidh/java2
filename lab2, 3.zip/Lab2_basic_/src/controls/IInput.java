package controls;

import java.util.Scanner;

public interface IInput {

	Scanner scanner = new Scanner(System.in);

	void input();
}
