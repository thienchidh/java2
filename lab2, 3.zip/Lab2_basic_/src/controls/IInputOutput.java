package controls;

public interface IInputOutput extends IOutput, IInput {

}
