package test;

import controls.MyManage;

public class Main {
	public static void main(String[] args) {
		new MyManage().run();
	}
}
