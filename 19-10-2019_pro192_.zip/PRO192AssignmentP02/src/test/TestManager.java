package test;

import controls.CustomerCare;

public class TestManager {
	public static void main(String[] args) {
		new CustomerCare().run();
	}
}
