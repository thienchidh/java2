package test;

import controls.StoreManagement;

public class TestManager {
	public static void main(String[] args) {
		new StoreManagement().run();
	}
}
